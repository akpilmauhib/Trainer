<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Dompdf extends CI_Controller
{
	public function pdf()
	{
		$this->load->library('dompdf_gen');
		$data['dashboard'] = $this->m_App->tampil_data('tbl_member');
		$this->load->view('laporanpdf', $data);

		$paper_size = 'A4';
		$orientation = 'portrait';
		$html = $this->output->get_output();
		$this->dompdf->set_paper($paper_size, $orientation);
		$this->dompdf->render();
		$this->dompdf->stream("Laporan Trainer Coaching.pdf", array('Attachment' => 0));
	}
}
